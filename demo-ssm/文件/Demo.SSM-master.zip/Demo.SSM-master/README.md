# SSM-Demo
SSM（spring+springmvc+mybatis）框架 Demo

应某网络友人邀约，需要一个SSM框架的Demo作为基础学习资料，于是乎，就有了本文。一个从零开始的SSM框架Demo对一个新手来说，是非常重要的，可大大减少在学习过程中遇到的各种各样的坑，说到最后，也算是助人为乐吧！

本Demo是在IDEA下搭建的Maven项目，在进行下面阅读前先了解这一点！

搭建框架的详细步骤见本人博客：

http://www.cnblogs.com/7tiny/p/7751732.html

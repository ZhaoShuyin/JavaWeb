说明：
   本项目是为springMVC+spring+mybatis的集成项目，使用maven进行项目管理
   版本说明：spring3.2  mybatis3.2 mysql5.6
   相关接口：
    用户接口+角色权限接口+博客接口。具体在Postman 1.1-2.5
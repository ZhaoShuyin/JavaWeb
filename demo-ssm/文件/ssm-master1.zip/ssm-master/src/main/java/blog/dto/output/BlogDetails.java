package blog.dto.output;
/**
 *
 * @Message:  created by Liujishuai on 2015年9月24日
 * 
 * @Description:
 */
public class BlogDetails {
	    private Integer id;

	    private String title;

	    private String des;

		public Integer getId() {
			return id;
		}

		public void setId(Integer id) {
			this.id = id;
		}

		public String getTitle() {
			return title;
		}

		public void setTitle(String title) {
			this.title = title;
		}

		public String getDes() {
			return des;
		}

		public void setDes(String des) {
			this.des = des;
		}

	    
}


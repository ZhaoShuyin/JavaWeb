package com.leeyom.service.user;

import com.leeyom.pojo.User;

public interface UserService {
    public User getUserById(Integer userId);
}
